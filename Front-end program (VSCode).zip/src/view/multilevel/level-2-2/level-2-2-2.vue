<template>
  <div>
    <h3>多级菜单 -> 二级-2 -> 3级2</h3>
    <Input v-model="val" style="width: 200px"></Input>
  </div>
</template>
<script>
export default {
  name: 'level_2_2_2',
  data () {
    return {
      val: ''
    }
  }
}
</script>
