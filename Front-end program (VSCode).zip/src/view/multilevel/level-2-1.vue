<template>
  <div>多级菜单 -> 二级-1</div>
</template>
<script>
export default {
  name: 'level_2_1'
}
</script>
