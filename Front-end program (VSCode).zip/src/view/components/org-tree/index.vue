<template>
  <Card shadow style="height: 100%;width: 100%;overflow:hidden">
    <div class="department-outer">
      <div class="zoom-box">
        <zoom-controller v-model="zoom" :min="20" :max="200"></zoom-controller>
      </div>
      <div class="view-box">
        <org-view
          v-if="data"
          :data="data"
          :zoom-handled="zoomHandled"
          @on-menu-click="handleMenuClick"
        ></org-view>
      </div>
    </div>
  </Card>
</template>

<script>
import OrgView from './components/org-view.vue'
import ZoomController from './components/zoom-controller.vue'
import './index.less'
const menuDic = {
  edit: '编辑部门',
  detail: '查看部门',
  new: '新增子部门',
  delete: '删除部门'
}
export default {
  name: 'org_tree_page',
  components: {
    OrgView,
    ZoomController
  },
  data () {
    return {
      data: null,
      zoom: 100,
      treedata: {
        id: 0,
        label: 'HUCPs',
        children: [
          {
            id: 1,
            label: 'Dining Services',
            children: [
              {
                id: 12,
                label: 'Dining Services, Station',
                children: [
                  {
                    id: 20,
                    label: 'Dining Services, Station, Enterprise',
                    children: [
                      {
                        id: 25,
                        label: 'Dining Services, Station, Enterprise, School',
                        children: [
                          {
                            id: 30,
                            label: 'Dining Services, Station, Enterprise, School, Residential',
                            children: [
                              {
                                id: 32,
                                label: 'Dining Services, Station, Enterprise, School, Residential, Insurance',
                                children: []
                              },
                              {
                                id: 33,
                                label: 'Dining Services, Station, Enterprise, School, Residential, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 31,
                            label: 'Dining Services, Station, Enterprise, School, Insurance',
                            children: [
                              {
                                id: 34,
                                label: 'Dining Services, Station, Enterprise, School, Insurance, Government Agency',
                                children: []
                              }
                            ]
                          },
                        ]
                      },
                      {
                        id: 26,
                        label: 'Dining Services, Station, Enterprise, Residential',
                        children: [
                          {
                            id: 35,
                            label: 'Dining Services, Station, Enterprise, Residential, Medical',
                            children: [
                              {
                                id: 38,
                                label: 'Dining Services, Station, Enterprise, Residential, Medical, Insurance',
                                children: []
                              },
                              {
                                id: 39,
                                label: 'Dining Services, Station, Enterprise, Residential, Medical, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 36,
                            label: 'Dining Services, Station, Enterprise, Residential, Insurance',
                            children: [
                                  {
                                    id: 61,
                                    label: 'Dining Services, Station, Enterprise, Residential, Insurance, Government Agency',
                                    children: []
                                  },                           
                            ]
                          },
                          {
                            id: 37,
                            label: 'Dining Services, Station, Enterprise, Residential, Government Agency',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 27,
                        label: 'Dining Services, Station, Enterprise, Medical',
                        children: [
                          {
                            id: 40,
                            label: 'Dining Services, Station, Enterprise, Medical, Insurance',
                            children: [
                              {
                                id: 41,
                                label: 'Dining Services, Station, Enterprise, Medical, Insurance, Government Agency',
                                children: []
                              },
                            ]
                          },
                        ]
                      },
                      {
                        id: 28,
                        label: 'Dining Services, Station, Enterprise, Insurance',
                        children: []
                      },
                      {
                        id: 29,
                        label: 'Dining Services, Station, Enterprise, Government Agency',
                        children: []
                      },
                    ]
                  },
                  {
                    id: 21,
                    label: 'Dining Services, Station, Shopping Mall',
                    children: [
                      {
                        id: 41,
                        label: 'Dining Services, Station, Shopping Mall, School',
                        children: [
                          {
                            id: 46,
                            label: 'Dining Services, Station, Shopping Mall, School, Residential',
                            children: [
                              {
                                id: 50,
                                label: 'Dining Services, Station, Shopping Mall, School, Residential, Medical',
                                children: [
                                  {
                                    id: 53,
                                    label: 'Dining Services, Station, Shopping Mall, School, Residential, Medical, Insurance',
                                    children: []
                                  },
                                ]
                              },
                              {
                                id: 51,
                                label: 'Dining Services, Station, Shopping Mall, School, Residential, Insurance',
                                children: []
                              },
                              {
                                id: 52,
                                label: 'Dining Services, Station, Shopping Mall, School, Residential, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 47,
                            label: 'Dining Services, Station, Shopping Mall, School, Medical',
                            children: [
                              {
                                id: 54,
                                label: 'Dining Services, Station, Shopping Mall, School, Medical, Insurance',
                                children: []
                              },
                              {
                                id: 55,
                                label: 'Dining Services, Station, Shopping Mall, School, Medical, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 48,
                            label: 'Dining Services, Station, Shopping Mall, School, Insurance',
                            children: []
                          },
                          {
                            id: 49,
                            label: 'Dining Services, Station, Shopping Mall, School, Government Agency',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 42,
                        label: 'Dining Services, Station, Shopping Mall, Residential',
                        children: [
                          {
                            id: 56,
                            label: 'Dining Services, Station, Shopping Mall, Residential, Medical',
                            children: [
                              {
                                id: 59,
                                label: 'Dining Services, Station, Shopping Mall, Residential, Medical, Insurance',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 57,
                            label: 'Dining Services, Station, Shopping Mall, Residential, Insurance',
                            children: []
                          },
                          {
                            id: 58,
                            label: 'Dining Services, Station, Shopping Mall, Residential, Government Agency',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 43,
                        label: 'Dining Services, Station, Shopping Mall, Medical',
                        children: [
                          {
                            id: 60,
                            label: 'Dining Services, Station, Shopping Mall, Medical, Insurance',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 44,
                        label: 'Dining Services, Station, Shopping Mall, Insurance',
                        children: []
                      },
                      {
                        id: 45,
                        label: 'Dining Services, Station, Shopping Mall, Government Agency',
                        children: []
                      },
                    ]
                  },
                ]
              },
              {
                id: 13,
                label: 'Dining Services, Public Facilities',
                children: [
                      {
                        id: 61,
                        label: 'Dining Services, Public Facilities, Enterprise',
                        children: [
                              {
                                id: 67,
                                label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall',
                                children: [
                                        {
                                          id: 71,
                                          label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Residential',
                                          children: [
                                                    {
                                                      id: 74,
                                                      label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Residential, Medical',
                                                      children: []
                                                    },
                                                    {
                                                      id: 75,
                                                      label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Residential, Insurance',
                                                      children: []
                                                    },
                                          ]
                                        },
                                        {
                                          id: 72,
                                          label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Medical',
                                          children: [
                                                  {
                                                    id: 76,
                                                    label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Medical, Insurance',
                                                    children: []
                                                  },
                                          ]
                                        },
                                        {
                                          id: 73,
                                          label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Government Agency',
                                          children: []
                                        },
                                ]
                              },
                              {
                                id: 68,
                                label: 'Dining Services, Public Facilities, Enterprise, Residential',
                                children: [
                                        {
                                          id: 77,
                                          label: 'Dining Services, Public Facilities, Enterprise, Residential, Medical',
                                          children: [
                                                {
                                                  id: 79,
                                                  label: 'Dining Services, Public Facilities, Enterprise, Residential, Medical, Insurance',
                                                  children: []
                                                },
                                          ]
                                        },
                                        {
                                          id: 78,
                                          label: 'Dining Services, Public Facilities, Enterprise, Residential, Insurance',
                                          children: []
                                        },
                                ]
                              },
                              {
                                id: 69,
                                label: 'Dining Services, Public Facilities, Enterprise, Medical, Insurance',
                                children: [
                                      {
                                        id: 80,
                                        label: 'Dining Services, Public Facilities, Enterprise, Medical, Insurance, Government Agency',
                                        children: []
                                      },
                                ]
                              },
                              {
                                id: 70,
                                label: 'Dining Services, Public Facilities, Enterprise, Government Agency',
                                children: []
                              },
                        ]
                      },
                      {
                        id: 62,
                        label: 'Dining Services, Public Facilities, Shopping Mall',
                        children: [
                              {
                                id: 81,
                                label: 'Dining Services, Public Facilities, Shopping Mall, School',
                                children: [
                                        {
                                          id: 84,
                                          label: 'Dining Services, Public Facilities, Shopping Mall, School, Residential',
                                          children: [
                                                {
                                                  id: 87,
                                                  label: 'Dining Services, Public Facilities, Shopping Mall, School, Residential, Medical',
                                                  children: []
                                                },
                                          ]
                                        },
                                        {
                                          id: 85,
                                          label: 'Dining Services, Public Facilities, Shopping Mall, School, Medical',
                                          children: []
                                        },
                                        {
                                          id: 86,
                                          label: 'Dining Services, Public Facilities, Shopping Mall, School, Insurance',
                                          children: []
                                        },
                                ]
                              },
                              {
                                id: 82,
                                label: 'Dining Services, Public Facilities, Shopping Mall, Residential',
                                children: [
                                          {
                                            id: 88,
                                            label: 'Dining Services, Public Facilities, Shopping Mall, Residential, Medical',
                                            children: []
                                          },
                                          {
                                            id: 89,
                                            label: 'Dining Services, Public Facilities, Shopping Mall, Residential, Insurance',
                                            children: []
                                          },
                                ]
                              },
                              {
                                id: 83,
                                label: 'Dining Services, Public Facilities, Shopping Mall, Insurance',
                                children: []
                              },
                        ]
                      },
                      {
                        id: 63,
                        label: 'Dining Services, Public Facilities, School',
                        children: [
                                    {
                                      id: 90,
                                      label: 'Dining Services, Public Facilities, School, Residential',
                                      children: [
                                            {
                                              id: 90,
                                              label: 'Dining Services, Public Facilities, School, Residential, Medical',
                                              children: []
                                            },
                                      ]
                                    },
                                    {
                                      id: 91,
                                      label: 'Dining Services, Public Facilities, School, Medical',
                                      children: []
                                    },
                                    {
                                      id: 92,
                                      label: 'Dining Services, Public Facilities, School, Insurance',
                                      children: []
                                    },
                                    {
                                      id: 93,
                                      label: 'Dining Services, Public Facilities, School, Government Agency',
                                      children: []
                                    },
                        ]
                      },
                      {
                        id: 64,
                        label: 'Dining Services, Public Facilities, Residential',
                        children: [
                                {
                                  id: 94,
                                  label: 'Dining Services, Public Facilities, Residential, Medical, Insurance',
                                  children: []
                                },
                                {
                                  id: 95,
                                  label: 'Dining Services, Public Facilities, Residential, Medical',
                                  children: []
                                },                     
                        ]
                      },
                      {
                        id: 65,
                        label: 'Dining Services, Public Facilities, Medical, Insurance, Government Agency',
                        children: []
                      },
                      {
                        id: 66,
                        label: 'Dining Services, Public Facilities, Insurance, Government Agency',
                        children: []
                      },
                ]
              },
              {
                id: 14,
                label: 'Dining Services, Enterprise, Shopping Mall, Medical',
                children: [
                      {
                        id: 96,
                        label: 'Dining Services, Enterprise, Shopping Mall, Medical, Insurance',
                        children: []
                      },
                ]
              },
              {
                id: 15,
                label: 'Dining Services, Shopping Mall, Residential, Medical',
                children: [
                        {
                          id: 97,
                          label: 'Dining Services, Shopping Mall, Residential, Medical, Insurance',
                          children: []
                        },
                ]
              },
              {
                id: 16,
                label: 'Dining Services, School, Residential',
                children: [
                          {
                            id: 98,
                            label: 'Dining Services, School, Residential, Medical',
                            children: []
                          },
                          {
                            id: 99,
                            label: 'Dining Services, School, Residential, Insurance, Government Agency',
                            children: []
                          },
                ]
              },
              {
                id: 18,
                label: 'Dining Services, Residential',
                children: []
              },
            ]
          },
          {
            id: 2,
            label: 'Station',
            children: [
                {
                  id: 2,
                  label: 'Station',
                  children: []
                },
            ]
          },
          {
            id: 3,
            label: 'Public Facilities',
            children: [
                {
                  id: 3,
                  label: 'Public Facilities',
                  children: []
                },
            ]
          },
          {
            id: 4,
            label: 'Enterprise',
            children: [
                  {
                    id: 4,
                    label: 'Enterprise',
                    children: []
                  },
            ]
          },
          {
            id: 5,
            label: 'Shopping Mall',
            children: [
                  {
                    id: 5,
                    label: 'Shopping Mall',
                    children: []
                  },
            ]
          },
          {
            id: 6,
            label: 'School',
            children: [
                  {
                    id: 6,
                    label: 'School',
                    children: []
                  },
            ]
          },
          {
            id: 7,
            label: 'Auto Repair',
            children: [
                {
                  id: 7,
                  label: 'Auto Repair',
                  children: []
                },
            ]
          },
          {
            id: 8,
            label: 'Residential',
            children: [
                {
                  id: 8,
                  label: 'Residential',
                  children: []
                },
            ]
          },
          {
            id: 9,
            label: 'Medical',
            children: [
                {
                  id: 9,
                  label: 'Medical',
                  children: []
                },
            ]
          },
          {
            id: 10,
            label: 'Insurance',
            children: [
                {
                  id: 10,
                  label: 'Insurance',
                  children: []
                },
            ]
          },
          {
            id: 11,
            label: 'Government Agency',
            children: [
                {
                  id: 11,
                  label: 'Government Agency',
                  children: []
                },
            ]
          },
        ]
      }
    }
  },
  computed: {
    zoomHandled () {
      return this.zoom / 100
    }
  },
  methods: {
    setDepartmentData (data) {
      data.isRoot = true
      return data
    },
    handleMenuClick ({ data, key }) {
      this.$Message.success({
        duration: 5,
        content: `点击了《${data.label}》节点的'${menuDic[key]}'菜单`
      })
    },
    getDepartmentData () {
      console.log('11111111111111')
      this.data = this.treedata
      // getOrgData().then(res => {
      //   const { data } = res
      //   this.data = data
      //   console.log(this.data, '4444444444444444444444444')
      // })
      // console.log('22222222222222'')
    }
  },
  mounted () {
    this.getDepartmentData()
  }
}
</script>

<style>
</style>
