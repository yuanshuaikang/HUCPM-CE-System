<template>
  <div>
    <!-- <Row :gutter="20">
      <i-col :xs="12" :md="8" :lg="4" v-for="(infor, i) in inforCardData" :key="`infor-${i}`" style="height: 120px;padding-bottom: 10px;">
        <infor-card shadow :color="infor.color" :icon="infor.icon" :icon-size="36">
          <count-to :end="infor.count" count-class="count-style"/>
          <p>{{ infor.title }}</p>
        </infor-card>
      </i-col>
    </Row> -->


    <Row >
      <i-col>
        <p :class="['custom-title', { 'bold-text': isBold }]">
            HUCPM-CE System
          </p>
      </i-col>
    </Row>
    

    <Row style="height:90px; margin-bottom: 20px;" >
    <el-card shadow="hover" class="custom-card">
      <el-button type="primary" @click="dialogVisible = true" icon="el-icon-caret-right">Run</el-button>
      <el-button type="danger" icon="el-icon-close" @click="reloadPage">End</el-button>
      <el-button type="info" icon="el-icon-message" circle></el-button>
       <el-button type="warning" icon="el-icon-star-off" circle></el-button>
      <el-button type="success" icon="el-icon-info" circle></el-button>
      <el-button type="primary" @click="CheckVisible = true;getDepartmentData()" icon="el-icon-caret-right">Check</el-button>

      <el-dialog title="Mining Results" :visible.sync="CheckVisible" custom-class="custom-dialog" style="height: 1000px;width: 2300px;">
        <div style="height: 640px;width: 1560px;margin: auto;">
          <Card shadow style="height: 100%;width: 100%;margin: auto; overflow:hidden">
            <div class="department-outer" >
              <div class="view-box">
                <org-view
                  v-if="data"
                  :data="data"
                  :zoom-handled="zoomHandled"
                  @on-menu-click="handleMenuClick"
                ></org-view>
              </div>
                   
            </div>
          </Card>
              <zoom-controller v-model="zoom" :min="0" :max="100" style="margin: auto; width: 150px;"></zoom-controller>
          </div>
       
      </el-dialog>

      <el-dialog title="Input Parameters" :visible.sync="dialogVisible" width="30%">
        <el-form ref="info" :model="info" label-width="200px">
          <el-form-item label="Sample size :">
            <el-input v-model="info.sample_space"></el-input>
          </el-form-item>
          <el-form-item label="Window size :">
            <el-input v-model="info.min_gap"></el-input>
          </el-form-item>
          <el-form-item label="Incoming Csv file :">
            <el-input v-model="info.adress"></el-input>
          </el-form-item>
          <el-form-item label="Number of iterations :">
            <el-input v-model="info.iterative"></el-input>
          </el-form-item>
          <el-form-item label="Minimum utility threshold :">
            <el-input v-model="info.min_utility"></el-input>
          </el-form-item>
          <el-form-item label="Minimum distance threshold :">
            <el-input v-model="info.min_dist"></el-input>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">Cancel</el-button>
          <el-button type="primary" @click="dialogVisible = false; handleConfirm();">Confirm</el-button>
        </span>
      </el-dialog>
    </el-card>
  </Row>
  


  <Row >
    <i-col span="8">
      <Card>
        <Table height = "616" :columns="columns" :data="paginatedData" />
        <div class="pagination-container">
      <el-pagination
        :current-page="currentPage"      
        :page-size="pageSize"            
        :total="tableData.length"        
        layout="prev, pager, next"
        @current-change="handlePageChange" 
      />
    </div>
      </Card>    
    </i-col>
    <i-col span="16">
      <Card id="container" shadow > 
      </Card>
    </i-col>
  </Row>

  
    <Row>
      <Card shadow >
        <!-- <example style="height: 310px;"/> -->
        <div  ref="dom" style="height: 400px; width: auto;"></div>
      </Card>
    </Row>

    <Row :gutter="20" style="margin-top: 20px; margin-bottom: 20px;">
      <i-col span="8" class="padding-left-10" >
        <Card style="height: 483px;">
          <p slot="title" :class="['custom-title', { 'bold-text': isBold }]" style="font-size: 20px;">
            Dataset Information
          </p>
          <Row type="flex" justify="center" align="middle" class="countto-page-row">
            <div class="count-to-con">
              <count-to :simplify="true"  :end="this.feature_number" count-class="count-text" unit-class="unit-class">
                <span class="slot-text" slot="left">Number of Features：</span>.
              </count-to>
              <count-to :simplify="true"  :end="this.instance_number" count-class="count-text" unit-class="unit-class">
                <span class="slot-text" slot="left">Number of Instances：</span>.
              </count-to>
              <count-to :simplify="true"  :end="this.max_instance" count-class="count-text" unit-class="unit-class">
                <span class="slot-text" slot="left">Features with the most instances：{{ [max_instance_feature]}}</span>.
              </count-to>
              <count-to :simplify="true"  :end="this.min_instance" count-class="count-text" unit-class="unit-class">
                <span class="slot-text" slot="left">Features with the fewest instances：{{ [min_instance_feature]}}</span>.
              </count-to>
              <count-to :simplify="true"  :end="this.max_total_utility" count-class="count-text" unit-class="unit-class"> 
                <span class="slot-text" slot="left">Features with the greatest total utility：{{ [max_total_utility_feature]}}</span>.
              </count-to>
              <count-to :simplify="true"  :end="this.max_feature_utility" count-class="count-text" unit-class="unit-class">
                <span class="slot-text" slot="left">The feature with the highest utility value：{{ [max_feature_utility_feature] }}</span>.
              </count-to>        
              <count-to :simplify="true"  :end="this.average" count-class="count-text" unit-class="unit-class">
                <span class="slot-text" slot="left">Average number of neighboring Instances：</span>.
              </count-to>
            </div>
          </Row>
        </Card>
      </i-col>

      <i-col :md="24" :lg="16" style="margin-bottom: 10px;">
        <Card shadow >
          <!-- <chart-bar style="height: 300px;" :value="barData" text="每周用户活跃量" v-if="show1"/>
          <chart-bar style="height: 300px;" :value="barData" text="每周用户活跃量" v-if="show2"/> -->
          <div ref="dom1" style="height: 450px; " >1111</div>
        </Card>
      </i-col>

    </Row>
    
    <footer class="footer" style="height: 10px;">
      <p>
        Copyright © 2024 HUCPM-CE System. All rights reserved.
      </p>
    </footer>

  

  </div>
</template>


<script>
// import {getallpicuter} from '@/api/data'

import InforCard from '_c/info-card'
import CountTo from '_c/count-to'
import { ChartPie, ChartBar } from '_c/charts'
import Example from './example.vue'
import {getAllshopping_msg} from '@/api/data'
import {getallpicuter} from '@/api/data'
import {getcolocation} from '@/api/data'
// import {getUserInfo} from '@/api/user'
import echarts from 'echarts'
import { on, off } from '@/libs/tools'
import tdTheme from './../../../components/charts/theme.json'
import { del } from 'vue'
import AMapLoader from '@amap/amap-jsapi-loader';
import OrgView from '././../../components/org-tree/components/org-view.vue'
import ZoomController from '././../../components/org-tree/components/zoom-controller.vue'
import '././../../components/org-tree/index.less'
// import Tables from '_c/tables'
echarts.registerTheme('tdTheme', tdTheme)

const menuDic = {
  edit: '编辑部门',
  detail: '查看部门',
  new: '新增子部门',
  delete: '删除部门'
}

export default {
  name: 'home',
  components: {
    InforCard,
    CountTo,
    ChartPie,
    ChartBar,
    OrgView,
    ZoomController,
    // Tables,
    Example
  },

  data () {
    return {
      columns: [
      {
        key: "Feature",
        title: "Feature",
        __id: "zY12tC"
      },
      {
        key: "Instance",
        title: "Instance",
        __id: "QBXhIN"
      },
      {
        key: "LocX",
        title: "LocX",
        __id: "EWMI9T"
      },
      {
        key: "LocY",
        title: "LocY",
        __id: "BNUIJc"
      },
      {
        key: "Checkin",
        title: "Checkin",
        __id: "NELLgy"
      }
      ],
      tableData: [],
      currentPage: 1, // 当前页
      pageSize: 20,    // 每页显示的条数
      isBold: true,  // 控制字体加粗
      href:'',
      shopping_msg:[],
      pictuer:[],
      barData: {
      },
      myChart: {},
      info:{
        "adress":"C:/Users/huawei/Desktop/项目/Beijing_haidian.csv",
        "min_utility":500,
        "min_dist":0.0013,
        "iterative":50,
        "sample_space":500,
        "min_gap":3
      },
      res: {
      },
      clock:0,
      show1:false,
      show2:true,
      Probability_dict:{},
      barchart: {},
      dis_echart:{},
      dialogVisible:false,
      CheckVisible:false,

      line_change: false,
      satisfiy: {
      },
      feature_number:0,
      instance_number:0,
      max_instance:0,
      min_instance:0,
      max_instance_feature:'',
      min_instance_feature:'',
      max_total_utility:0,
      max_total_utility_feature:'',
      max_feature_utility:0,
      max_feature_utility_feature:'',
      average:0,
      positions : [],

      HUCPsdata: null,
      zoom: 100,
      treedata: {
        id: 0,
        label: 'HUCPs',
        children: [
          {
            id: 2,
            label: 'Station',
            children: [
                {
                  id: 2,
                  label: 'Station',
                  children: []
                },
            ]
          },
          {
            id: 3,
            label: 'Public Facilities',
            children: [
                {
                  id: 3,
                  label: 'Public Facilities',
                  children: []
                },
            ]
          },
          {
            id: 4,
            label: 'Enterprise',
            children: [
                  {
                    id: 4,
                    label: 'Enterprise',
                    children: []
                  },
            ]
          },
          {
            id: 5,
            label: 'Shopping Mall',
            children: [
                  {
                    id: 5,
                    label: 'Shopping Mall',
                    children: []
                  },
            ]
          },
          {
            id: 1,
            label: 'Dining Services',
            children: [
              {
                id: 12,
                label: 'Dining Services, Station',
                children: [
                  {
                    id: 20,
                    label: 'Dining Services, Station, Enterprise',
                    children: [
                      {
                        id: 25,
                        label: 'Dining Services, Station, Enterprise, School',
                        children: [
                          {
                            id: 30,
                            label: 'Dining Services, Station, Enterprise, School, Residential',
                            children: [
                              {
                                id: 32,
                                label: 'Dining Services, Station, Enterprise, School, Residential, Insurance',
                                children: []
                              },
                              {
                                id: 33,
                                label: 'Dining Services, Station, Enterprise, School, Residential, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 31,
                            label: 'Dining Services, Station, Enterprise, School, Insurance',
                            children: [
                              {
                                id: 34,
                                label: 'Dining Services, Station, Enterprise, School, Insurance, Government Agency',
                                children: []
                              }
                            ]
                          },
                        ]
                      },
                      {
                        id: 26,
                        label: 'Dining Services, Station, Enterprise, Residential',
                        children: [
                          {
                            id: 35,
                            label: 'Dining Services, Station, Enterprise, Residential, Medical',
                            children: [
                              {
                                id: 38,
                                label: 'Dining Services, Station, Enterprise, Residential, Medical, Insurance',
                                children: []
                              },
                              {
                                id: 39,
                                label: 'Dining Services, Station, Enterprise, Residential, Medical, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 36,
                            label: 'Dining Services, Station, Enterprise, Residential, Insurance',
                            children: [
                                  {
                                    id: 61,
                                    label: 'Dining Services, Station, Enterprise, Residential, Insurance, Government Agency',
                                    children: []
                                  },                           
                            ]
                          },
                          {
                            id: 37,
                            label: 'Dining Services, Station, Enterprise, Residential, Government Agency',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 27,
                        label: 'Dining Services, Station, Enterprise, Medical',
                        children: [
                          {
                            id: 40,
                            label: 'Dining Services, Station, Enterprise, Medical, Insurance',
                            children: [
                              {
                                id: 41,
                                label: 'Dining Services, Station, Enterprise, Medical, Insurance, Government Agency',
                                children: []
                              },
                            ]
                          },
                        ]
                      },
                      {
                        id: 28,
                        label: 'Dining Services, Station, Enterprise, Insurance',
                        children: []
                      },
                      {
                        id: 29,
                        label: 'Dining Services, Station, Enterprise, Government Agency',
                        children: []
                      },
                    ]
                  },
                  {
                    id: 21,
                    label: 'Dining Services, Station, Shopping Mall',
                    children: [
                      {
                        id: 41,
                        label: 'Dining Services, Station, Shopping Mall, School',
                        children: [
                          {
                            id: 46,
                            label: 'Dining Services, Station, Shopping Mall, School, Residential',
                            children: [
                              {
                                id: 50,
                                label: 'Dining Services, Station, Shopping Mall, School, Residential, Medical',
                                children: [
                                  {
                                    id: 53,
                                    label: 'Dining Services, Station, Shopping Mall, School, Residential, Medical, Insurance',
                                    children: []
                                  },
                                ]
                              },
                              {
                                id: 51,
                                label: 'Dining Services, Station, Shopping Mall, School, Residential, Insurance',
                                children: []
                              },
                              {
                                id: 52,
                                label: 'Dining Services, Station, Shopping Mall, School, Residential, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 47,
                            label: 'Dining Services, Station, Shopping Mall, School, Medical',
                            children: [
                              {
                                id: 54,
                                label: 'Dining Services, Station, Shopping Mall, School, Medical, Insurance',
                                children: []
                              },
                              {
                                id: 55,
                                label: 'Dining Services, Station, Shopping Mall, School, Medical, Government Agency',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 48,
                            label: 'Dining Services, Station, Shopping Mall, School, Insurance',
                            children: []
                          },
                          {
                            id: 49,
                            label: 'Dining Services, Station, Shopping Mall, School, Government Agency',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 42,
                        label: 'Dining Services, Station, Shopping Mall, Residential',
                        children: [
                          {
                            id: 56,
                            label: 'Dining Services, Station, Shopping Mall, Residential, Medical',
                            children: [
                              {
                                id: 59,
                                label: 'Dining Services, Station, Shopping Mall, Residential, Medical, Insurance',
                                children: []
                              },
                            ]
                          },
                          {
                            id: 57,
                            label: 'Dining Services, Station, Shopping Mall, Residential, Insurance',
                            children: []
                          },
                          {
                            id: 58,
                            label: 'Dining Services, Station, Shopping Mall, Residential, Government Agency',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 43,
                        label: 'Dining Services, Station, Shopping Mall, Medical',
                        children: [
                          {
                            id: 60,
                            label: 'Dining Services, Station, Shopping Mall, Medical, Insurance',
                            children: []
                          },
                        ]
                      },
                      {
                        id: 44,
                        label: 'Dining Services, Station, Shopping Mall, Insurance',
                        children: []
                      },
                      {
                        id: 45,
                        label: 'Dining Services, Station, Shopping Mall, Government Agency',
                        children: []
                      },
                    ]
                  },
                ]
              },
              {
                id: 13,
                label: 'Dining Services, Public Facilities',
                children: [
                      {
                        id: 61,
                        label: 'Dining Services, Public Facilities, Enterprise',
                        children: [
                              {
                                id: 67,
                                label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall',
                                children: [
                                        {
                                          id: 71,
                                          label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Residential',
                                          children: [
                                                    {
                                                      id: 74,
                                                      label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Residential, Medical',
                                                      children: []
                                                    },
                                                    {
                                                      id: 75,
                                                      label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Residential, Insurance',
                                                      children: []
                                                    },
                                          ]
                                        },
                                        {
                                          id: 72,
                                          label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Medical',
                                          children: [
                                                  {
                                                    id: 76,
                                                    label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Medical, Insurance',
                                                    children: []
                                                  },
                                          ]
                                        },
                                        {
                                          id: 73,
                                          label: 'Dining Services, Public Facilities, Enterprise, Shopping Mall, Government Agency',
                                          children: []
                                        },
                                ]
                              },
                              {
                                id: 68,
                                label: 'Dining Services, Public Facilities, Enterprise, Residential',
                                children: [
                                        {
                                          id: 77,
                                          label: 'Dining Services, Public Facilities, Enterprise, Residential, Medical',
                                          children: [
                                                {
                                                  id: 79,
                                                  label: 'Dining Services, Public Facilities, Enterprise, Residential, Medical, Insurance',
                                                  children: []
                                                },
                                          ]
                                        },
                                        {
                                          id: 78,
                                          label: 'Dining Services, Public Facilities, Enterprise, Residential, Insurance',
                                          children: []
                                        },
                                ]
                              },
                              {
                                id: 69,
                                label: 'Dining Services, Public Facilities, Enterprise, Medical, Insurance',
                                children: [
                                      {
                                        id: 80,
                                        label: 'Dining Services, Public Facilities, Enterprise, Medical, Insurance, Government Agency',
                                        children: []
                                      },
                                ]
                              },
                              {
                                id: 70,
                                label: 'Dining Services, Public Facilities, Enterprise, Government Agency',
                                children: []
                              },
                        ]
                      },
                      {
                        id: 62,
                        label: 'Dining Services, Public Facilities, Shopping Mall',
                        children: [
                              {
                                id: 81,
                                label: 'Dining Services, Public Facilities, Shopping Mall, School',
                                children: [
                                        {
                                          id: 84,
                                          label: 'Dining Services, Public Facilities, Shopping Mall, School, Residential',
                                          children: [
                                                {
                                                  id: 87,
                                                  label: 'Dining Services, Public Facilities, Shopping Mall, School, Residential, Medical',
                                                  children: []
                                                },
                                          ]
                                        },
                                        {
                                          id: 85,
                                          label: 'Dining Services, Public Facilities, Shopping Mall, School, Medical',
                                          children: []
                                        },
                                        {
                                          id: 86,
                                          label: 'Dining Services, Public Facilities, Shopping Mall, School, Insurance',
                                          children: []
                                        },
                                ]
                              },
                              {
                                id: 82,
                                label: 'Dining Services, Public Facilities, Shopping Mall, Residential',
                                children: [
                                          {
                                            id: 88,
                                            label: 'Dining Services, Public Facilities, Shopping Mall, Residential, Medical',
                                            children: []
                                          },
                                          {
                                            id: 89,
                                            label: 'Dining Services, Public Facilities, Shopping Mall, Residential, Insurance',
                                            children: []
                                          },
                                ]
                              },
                              {
                                id: 83,
                                label: 'Dining Services, Public Facilities, Shopping Mall, Insurance',
                                children: []
                              },
                        ]
                      },
                      {
                        id: 63,
                        label: 'Dining Services, Public Facilities, School',
                        children: [
                                    {
                                      id: 90,
                                      label: 'Dining Services, Public Facilities, School, Residential',
                                      children: [
                                            {
                                              id: 90,
                                              label: 'Dining Services, Public Facilities, School, Residential, Medical',
                                              children: []
                                            },
                                      ]
                                    },
                                    {
                                      id: 91,
                                      label: 'Dining Services, Public Facilities, School, Medical',
                                      children: []
                                    },
                                    {
                                      id: 92,
                                      label: 'Dining Services, Public Facilities, School, Insurance',
                                      children: []
                                    },
                                    {
                                      id: 93,
                                      label: 'Dining Services, Public Facilities, School, Government Agency',
                                      children: []
                                    },
                        ]
                      },
                      {
                        id: 64,
                        label: 'Dining Services, Public Facilities, Residential',
                        children: [
                                {
                                  id: 94,
                                  label: 'Dining Services, Public Facilities, Residential, Medical, Insurance',
                                  children: []
                                },
                                {
                                  id: 95,
                                  label: 'Dining Services, Public Facilities, Residential, Medical',
                                  children: []
                                },                     
                        ]
                      },
                      {
                        id: 65,
                        label: 'Dining Services, Public Facilities, Medical, Insurance, Government Agency',
                        children: []
                      },
                      {
                        id: 66,
                        label: 'Dining Services, Public Facilities, Insurance, Government Agency',
                        children: []
                      },
                ]
              },
              {
                id: 14,
                label: 'Dining Services, Enterprise, Shopping Mall, Medical',
                children: [
                      {
                        id: 96,
                        label: 'Dining Services, Enterprise, Shopping Mall, Medical, Insurance',
                        children: []
                      },
                ]
              },
              {
                id: 15,
                label: 'Dining Services, Shopping Mall, Residential, Medical',
                children: [
                        {
                          id: 97,
                          label: 'Dining Services, Shopping Mall, Residential, Medical, Insurance',
                          children: []
                        },
                ]
              },
              {
                id: 16,
                label: 'Dining Services, School, Residential',
                children: [
                          {
                            id: 98,
                            label: 'Dining Services, School, Residential, Medical',
                            children: []
                          },
                          {
                            id: 99,
                            label: 'Dining Services, School, Residential, Insurance, Government Agency',
                            children: []
                          },
                ]
              },
              {
                id: 18,
                label: 'Dining Services, Residential',
                children: []
              },
            ]
          },
          {
            id: 6,
            label: 'School',
            children: [
                  {
                    id: 6,
                    label: 'School',
                    children: []
                  },
            ]
          },
          {
            id: 7,
            label: 'Auto Repair',
            children: [
                {
                  id: 7,
                  label: 'Auto Repair',
                  children: []
                },
            ]
          },
          {
            id: 8,
            label: 'Residential',
            children: [
                {
                  id: 8,
                  label: 'Residential',
                  children: []
                },
            ]
          },
          {
            id: 9,
            label: 'Medical',
            children: [
                {
                  id: 9,
                  label: 'Medical',
                  children: []
                },
            ]
          },
          {
            id: 10,
            label: 'Insurance',
            children: [
                {
                  id: 10,
                  label: 'Insurance',
                  children: []
                },
            ]
          },
          {
            id: 11,
            label: 'Government Agency',
            children: [
                {
                  id: 11,
                  label: 'Government Agency',
                  children: []
                },
            ]
          },
        ]
      }
      // treedata:{}


    }
  },  
  computed: {
    // 根据分页状态计算当前页的数据
    paginatedData() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = this.currentPage * this.pageSize;
      return this.tableData.slice(start, end);
    },
    zoomHandled () {
      return this.zoom / 100
    }
  },

  methods:{
    init_chart(){
      this.myChart = echarts.init(this.$refs.dom);
      var option = {
        title: {
          text: 'Iteration progress',
          textAlign: 'center', 
          textVerticalAlign: 'middle', 
          padding: [10, 10],
          x:'50%', // 
          top: '1%', // 标题距离容器上侧的距离，可以是像素值或百分比
          textStyle: {
            fontSize: '20',
            fontWeight: 'bold',
            color: '#333'
          },
          subtextStyle: {
            fontSize: 14,
            color: '#666'
          }
        },

        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',

            label: {
              backgroundColor: '#6a7985'
            }
          }
        },

        grid: {
          top: '10%',
          left: '2%',
          right: '1.5%',
          bottom: '5%',
          containLabel: true
        },

        xAxis: [
          {
            type: 'value',
            boundaryGap: true,
            min: 0, 
            max: this.info.iterative, 
            interval: 1, 
            axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 12] 
            },
            name: 'Iteration',            // 纵坐标名称
            nameLocation: 'middle',   // 纵坐标名称位置，可以是 'start', 'middle', 'end'
            nameGap: 25,           // 坐标轴名称与轴线的距离
            nameTextStyle: {
              color: '#333',           // 坐标轴名称的颜色（例如深橙色）
              fontSize: 16,               // 坐标轴名称的字体大小
              fontWeight: 'bold',         // 坐标轴名称的字体加粗
              fontFamily: 'Arial',        // 坐标轴名称的字体
            }
          }
        ],

        yAxis: [
          {
            min: 0, // 最小值
            max: this.info.sample_space, // 最大值
            interval: null, // 每个刻度的间隔
            axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 12] 
            },
            name: 'Number of patterns',            // 纵坐标名称
            nameLocation: 'middle',   // 纵坐标名称位置，可以是 'start', 'middle', 'end'
            nameGap: 35,           // 坐标轴名称与轴线的距离
            nameTextStyle: {
              color: '#333',           // 坐标轴名称的颜色（例如深橙色）
              fontSize: 16,               // 坐标轴名称的字体大小
              fontWeight: 'bold',         // 坐标轴名称的字体加粗
              fontFamily: 'Arial',        // 坐标轴名称的字体
            }

          }
        ],

        series: [
          {
            name: 'The number of patterns to check per iteration',
            type: 'line',
            // stack: '总量',
            label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
            areaStyle: { normal: {
              color: '#2d8cf0'
            } },
            data: []
          },
          {
            name: 'The number of HUCPs found in each iteration',
            type: 'line',
            // stack: '总量',
            label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
            areaStyle: { normal: {
              color: '#10A6FF'
            } },
            data: []
          }
        
        ]
      }

      this.myChart.setOption(option);
      on(window, 'resize', this.resize)
    },

    getchart () {
      this.myChart = echarts.init(this.$refs.dom);
      var option = {
        title: {
          text: 'Iteration progress',
          textAlign: 'center', 
          textVerticalAlign: 'middle', 
          padding: [10, 10],
          x:'50%', // 
          top: '1%', // 标题距离容器上侧的距离，可以是像素值或百分比
          textStyle: {
            fontSize: '20',
            fontWeight: 'bold',
            color: '#333'
          },
          subtextStyle: {
            fontSize: 14,
            color: '#666'
          }
        },

        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross',

            label: {
              backgroundColor: '#6a7985'
            }
          }
        },

        grid: {
          top: '10%',
          left: '2%',
          right: '1.5%',
          bottom: '5%',
          containLabel: true
        },

        xAxis: [
          {
            type: 'value',
            boundaryGap: true,
            min: 0, 
            max: this.info.iterative, 
            interval: 1, 
            axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 12] 
            },
            name: 'Iteration',          
            nameLocation: 'middle',   // 纵坐标名称位置，可以是 'start', 'middle', 'end'
            nameGap: 25,           // 坐标轴名称与轴线的距离
            nameTextStyle: {
              color: '#333',           // 坐标轴名称的颜色（例如深橙色）
              fontSize: 16,               // 坐标轴名称的字体大小
              fontWeight: 'bold',         // 坐标轴名称的字体加粗
              fontFamily: 'Arial',        // 坐标轴名称的字体
            }
          }
        ],

        yAxis: [
          {
            min: 0, // 最小值
            max: this.info.sample_space, // 最大值
            interval: null, // 每个刻度的间隔
            axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 12] 
            },
            name: 'Number of patterns',            // 纵坐标名称
            nameLocation: 'middle',   // 纵坐标名称位置，可以是 'start', 'middle', 'end'
            nameGap: 35,           // 坐标轴名称与轴线的距离
            nameTextStyle: {
              color: '#333',           // 坐标轴名称的颜色（例如深橙色）
              fontSize: 16,               // 坐标轴名称的字体大小
              fontWeight: 'bold',         // 坐标轴名称的字体加粗
              fontFamily: 'Arial',        // 坐标轴名称的字体
            }

          }
        ],
        series: [
          {
            name: 'The number of patterns to check per iteration',
            type: 'line',
            label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
            data: []
          },
          {
            name: 'The number of HUCPs found in each iteration',
            type: 'line',
            areaStyle: { normal: {
              color: '#10A6FF'
            } },
            label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
            data:[]
          }
        
        ]
      }

      this.myChart.setOption(option);
      on(window, 'resize', this.resize)
    },

    change(){
      var option = this.myChart.getOption();
      var value = this.res.data.Exam_pattern_number[this.clock];
      var value2 = this.res.data.Satisfy_number[this.clock];
      let symbol = this.res.data.Variation[this.clock] === 1 ? 'triangle' : 'circle';

      option.series[0].data.push({
        value: [this.clock + 1, value],
        symbol: symbol,  // 设置点的图形为星形或圆形
        symbolSize: 10    // 设置图形的大小
      });
      // console.log(option.series[0].data[0][2],'ssssssssssssss');
      // console.log(typeof option.series[0].data[0],'aaaaaaaaaaaaaa');
      // console.log(typeof option.series[1].data[0],'bbbbbbbbbbbbbb');   
      
      option.series[1].data.push({
        value:[this.clock + 1, value2],
        symbol: symbol,  // 设置点的图形为星形或圆形
        symbolSize: 10    // 设置图形的大小
      });

      // 将横坐标设置为 clock，纵坐标设置为对应的值
      // option.series[0].data.push([this.clock + 1, value]);
      // option.series[0].data.push(this.res.data.Exam_pattern_number[this.clock])
      this.myChart.setOption(option);
      this.clock += 1;
      // off(window, 'resize', this.resize)
      // on(window, 'resize', this.resize)
    },

    change2(){
      var option = this.dis_echart.getOption();
      var value = this.res.data.Probability[this.clock];
      value = value.map(item => Math.round(item * 100));
      option.xAxis[0].data = Object.keys(this.res.data.utility_value);

      option.series[0].data = value

      this.dis_echart.setOption(option);
      // this.clock += 1;
      // off(window, 'resize', this.resize)
      // on(window, 'resize', this.resize)
    },

    distribution_echart(){
      // console.log("disssssssssssssssssssssssss")
      this.dis_echart = echarts.init(this.$refs.dom1);
      // console.log(this.dis_echart)
      let option = {
        title: {
          text: 'High utility patterns probability distribution',
          subtext: this.subtext,
          x: 'center',
          textStyle: {
            fontSize: '20',
            fontWeight: 'bold',
            color: '#333'
          },
        },
        
        grid: {
          top: '12%',
          left: '2%',
          right: '4%',
          bottom: '1%',
          containLabel: true
        },

        xAxis: {
          type: 'category',
          data: ['A','B','C', 'D', 'E', 'F', 'G'],
          axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 13] 
            },
            axisLabel: {
              show: true,
              color: '#000',
              fontSize: 12, // 初始字体大小
              formatter: function(value) {
                // 根据标签长度自动调整字体大小
                return value.length > 1 ? `{a|${value}}` : value; // 示例逻辑
              },
            rich: {
                a: {
                  fontSize: 10, // 控制更大的标签显示较小的字体
                  lineHeight: 15
                }
            },
            interval: 0 // 显示所有标签
          }          
        },

        yAxis: {
          type: 'value',
          min: 0,
          max: 100,
          interval: 10,
          axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 14]  
            },
          axisLabel: {
            show: true,
            color: '#000', // 设置刻度字体颜色为黑色
            fontSize: '12',   // 设置字体大小（可选）
            // fontWeight: 'bold' // 设置字体加粗（可选）
          },
          name: 'Probability (%)',            // 纵坐标名称
          nameLocation: 'middle',   // 纵坐标名称位置，可以是 'start', 'middle', 'end'
          nameGap: 28,           // 坐标轴名称与轴线的距离
          nameTextStyle: {
            color: '#333',           // 坐标轴名称的颜色（例如深橙色）
            fontSize: 16,               // 坐标轴名称的字体大小
            fontWeight: 'bold',         // 坐标轴名称的字体加粗
            fontFamily: 'Arial',        // 坐标轴名称的字体
          }
        },

        series: [{
          data: [],
          type: 'bar', // 折线图
          smooth: true, // 启用平滑曲线
          itemStyle: {
            color: '#B22222', 
            borderColor: '#333',
            borderWidth: 1, 
          },
          barWidth: 30, // 设置柱子的宽度
          label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
        }]
        
      }

      // this.dis_echart = echarts.init(this.$refs.dom1, 'tdTheme')
      this.dis_echart.setOption(option)

      on(window, 'resize', this.resize)
    },

    getdata(){
      // console.log(this.info)
      getcolocation(this.info).then(res =>{
        this.res = res
        this.show1=true
        this.show2=false
        console.log(this.res.data)
        this.instance_number = this.res.data.INSTANCE_number
        this.feature_number = this.res.data.FEATURE_number
        this.max_instance_feature = this.res.data.MAX_INSTANCE[0]
        this.max_instance = this.res.data.MAX_INSTANCE[1]

        this.min_instance_feature = this.res.data.MIN_INSTANCE[0]
        this.min_instance = this.res.data.MIN_INSTANCE[1]

        this.max_total_utility_feature = this.res.data.MAX_TOTAL_UTILITY[0]
        this.max_total_utility = this.res.data.MAX_TOTAL_UTILITY[1]

        this.max_feature_utility_feature = this.res.data.MAX_FEATURE_VALUE[0]
        this.max_feature_utility = this.res.data.MAX_FEATURE_VALUE[1]

        this.average = this.res.data.AVERAGE

        this.positions = this.res.data.POSITIONS

        this.tableData = this.res.data.TABLE_information

        // this.treedata = this.res.data.Tree_struct
        
        // console.log(this.res.data.Tree_struct, "44444444444444444444")

        // console.log(this.res.data, "ddddddddddddddddddddd")

        // const probabilityValues = res.data.Probability[this.clock];
    
        // Object.keys(this.barData).forEach((key, index) => {
        //   this.barData[key] = null;
        //   console.log(`${key}: ${this.barData[key]}`);
        // });
        this.getchart(),
        this.addLabelsLayer(AMap)
      }).catch(err =>{
        console.log(err)
      })
    },  

    handleConfirm() {
      // this.addLabelsLayer(AMap);
      this.dialogVisible = false;
      // const this_=this
      this.getdata(),
      
    
      
      // const getalldata = async ()=>{
      //   await 
        
      // }
      // getalldata()
      console.log("2")
      

      // 启动定时器，每 5 秒调用一次 change() 和 change2()
      if (this.timer) {
        clearInterval(this.timer); // 清除已有的定时器，避免重复
      }

      let callCount = 0; // 用于计数调用次数

      this.timer = setInterval(() => {
        if (callCount >= this.info.iterative) {
          clearInterval(this.timer); // 如果达到最大次数，停止定时器
          return;
        }

        this.change();
        this.change2();
        callCount++; // 增加调用次数
        // console.log(callCount,"55555555555555555555565555")
      }, 1500);
    },

    stopInterval() {
      // 停止定时器的方法
      if (this.timer) {
        clearInterval(this.timer);
        this.timer = null;
        console.log("Timer stopped.");
      }
    },
    reloadPage() {
      location.reload();
    },

    initAMap() {
      window._AMapSecurityConfig = {
        securityJsCode: "432ebe93e5e825247bfd217419674c90",
      };
      AMapLoader.load({
        key: "432ebe93e5e825247bfd217419674c90", // 申请好的Web端开发者Key，首次调用 load 时必填
        version: "2.0", // 指定要加载的 JSAPI 的版本，缺省时默认为 1.4.15
        plugins: ["AMap.Scale","AMap.MassMarks","AMap.ToolBar","AMap.Scale","AMap.HawkEye", "AMap.MapType","AMap.Geolocation","AMap.ControlBar",], //需要使用的的插件列表，如比例尺'AMap.Scale'，支持添加多个如：['...','...']
      })
        .then((AMap) => {
          this.map = new AMap.Map("container", {
            // 设置地图容器id
            viewMode: "2D", // 是否为3D地图模式
            zoom: 11, // 初始化地图级别
            center: [116.397, 39.90970], // 初始化地图中心点位置
          });

          this.map.addControl(new AMap.ToolBar());

          //添加比例尺控件，展示地图在当前层级和纬度下的比例尺
          this.map.addControl(new AMap.Scale());

          //添加鹰眼控件，在地图右下角显示地图的缩略图
          this.map.addControl(new AMap.HawkEye({ isOpen: true }));

          //添加类别切换控件，实现默认图层与卫星图、实施交通图层之间切换的控制
          this.map.addControl(new AMap.MapType());

          //添加定位控件，用来获取和展示用户主机所在的经纬度位置
          this.map.addControl(new AMap.Geolocation());

          //添加控制罗盘控件，用来控制地图的旋转和倾斜
          this.map.addControl(new AMap.ControlBar());
          // 调用方法添加海量点
          // this.addMassMarks(AMap);
          // 调用方法添加 LabelsLayer 和 LabelMarker
          // this.addLabelsLayer(AMap);
        })
        .catch((e) => {
          console.log(e);
        });
    },

    addLabelsLayer(AMap) {
      // 设置图标对象
      const icons = [
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/ff2176545dd2af42733721010e0bd9de070019cd/GisFlagB.svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(2).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(3).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(4).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(5).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(6).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(7).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(8).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(9).svg",
          size: [15, 20],
          anchor: "center",
        },
        {
          type: "image",
          image: "https://raw.githubusercontent.com/yuanshuaikang/-/180e9951936f5c4addb2f2b349411218bf9db8b8/GisFlagB%20(10).svg",
          size: [15, 20],
          anchor: "center",
        },
      ];

  
      // 创建 LabelsLayer 实例
      const labelsLayer = new AMap.LabelsLayer({
        zooms: [3, 20],
        zIndex: 1000,
        collision: true, // 该层内标注是否避让
        allowCollision: true, // 不同标注层之间是否避让
      });



      // console.log(this.positions,'ssssssssssssssssssssssssssssssssss')
      // 遍历 positions 数组生成 LabelMarker
      this.positions.forEach((position, index) => {
        const randomIcon = icons[index % icons.length]; // 从十种图标中循环选择
        const labelMarker = new AMap.LabelMarker({
          name: `标注${index + 1}`, // 为每个标注设置唯一名称
          position: position, // 标注位置
          zIndex: 16,
          rank: 1, // 避让优先级
          icon: randomIcon, // 使用全局定义的图标
        });

        // 添加 LabelMarker 到 LabelsLayer
        labelsLayer.add(labelMarker);
      });

      // 添加 LabelsLayer 到地图
      this.map.add(labelsLayer);
      
    },
    
    handlePageChange(page) {
      this.currentPage = page;
    },

    setDepartmentData (data) {
      data.isRoot = true
      return data
    },
    handleMenuClick ({ data, key }) {
      this.$Message.success({
        duration: 5,
        content: `点击了《${data.label}》节点的'${menuDic[key]}'菜单`
      })
    },
    getDepartmentData () {
      this.data = this.treedata
    }
    


  },

  
  mounted () {
    // getallpicuter().then(res =>{
    //   console.log(res)
    //   this.pictuer = res.data
    // }).catch(err =>{
    //   console.log(err)
    // }),
    
    // getAllshopping_msg(1,'空调').then(res =>{
    //   // console.log(res)
    //   this.shopping_msg = res.data
      
    // }).catch(err =>{
    //   console.log(err)
    // }),

    // getallpicuter().then(res =>{
      
    //   this.wordcloud = res.data.data
      
    //   this.href = "data:imassge/png;base64,"+ this.wordcloud[0].hre
    //   console.log(this.href)
    //   // this.href = "https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg"
    // }).catch(err =>{
      // console.log(err)
    // }),
    
    //

    // this.getdata()
    this.init_chart()
    this.distribution_echart()

    this.initAMap();
    // this.getbarchart()

    setTimeout(() => {
      
      const resizeOb = new ResizeObserver((entries) => {
        for (const entry of entries) {
          echarts.getInstanceByDom(entry.target).resize();
        }
      });
      resizeOb.observe(this.$refs.dom);
      resizeOb.observe(this.$refs.dom1 );
    });

    this.stopInterval()

    

  },
  
}
</script>

<style lang="less">
.count-style{
  font-size: 50px;
}
.custom-title {
    font-size: 35px;
    font-weight: bold;
    line-height: 1.5;
    margin: 10px 0;
    display: flex;
    align-items: center;
}
.bold-text {
  font-weight: normal;
}
.countto-page-row{
  font-size: 18.5px;
  height: 14px;
  font-weight: bold;
  margin-top: 20px;  /* 调整顶部外边距 */
  margin-bottom: 15px; /* 调整底部外边距 */
  margin-left: 15px; /* 调整左侧外边距 */
  margin-right: 15px; /* 调整右侧外边距 */
  line-height: 2.5;
}
.count-to-con{
  display: block;
  width: 100%;
  text-align: left;
}

.custom-card {
  border-radius: 4px; /* 调整圆角 */
  background-color: #f5f5f5; /* 修改背景颜色 */
  border: 1px solid #dcdcdc; /* 自定义边框颜色 */
  box-shadow: 0 0px 0px rgba(167, 166, 166, 0.1); /* 调整阴影 */
  padding: -1px; /* 内边距 */
}


.footer {
  background-color: #f4f4f4; /* 底部背景色 */
  border-top: 1px solid #dcdcdc; /* 顶部边框 */
  padding: 18px 15px; /* 内边距 */
  text-align: center; /* 居中对齐 */
  font-size: 18px; /* 字体大小 */
  color: #494848; /* 字体颜色 */

}
#container{
        padding:0px;
        margin: 0px 0px 20px auto;
        width: 99%;
        height: 700px; 
}

.pagination-container {
  display: flex;
  justify-content: center; /* 水平居中 */
  align-items: center;    /* 垂直居中 */
  margin-top: 20px;       /* 与表格保持适当间距 */
}

.custom-dialog {
  width: 70%;  /* 调整宽度 */
  height: 75%; /* 调整高度 */
  max-height: 80vh; /* 设置最大高度（防止超出屏幕） */
}

</style>
