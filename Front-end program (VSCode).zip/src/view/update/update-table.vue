<template>
  <Row :gutter="10">
    <i-col span="6">
      <Card>
        <Upload action="" :before-upload="beforeUpload">
          <Button icon="ios-cloud-upload-outline">上传Csv文件</Button>
          &nbsp;&nbsp;&nbsp;&nbsp;点击上传Csv文件
        </Upload>
        <p>util.js提供两个方法用来实现这个功能：</p>
        <p class="update-table-intro"><Icon style="margin-right: 10px;" :size="10" type="md-heart"/><span class="code-high-line">getArrayFromFile</span>：将Csv文件解析为二维数组</p>
        <p class="update-table-intro"><Icon style="margin-right: 10px;" :size="10" type="md-heart"/><span class="code-high-line">getTableDataFromArray</span>：将二维数组转为表格数据，具体请看文档</p>
      </Card>
    </i-col>
    <i-col span="18">
      <Table :height="500" :columns="columns" :data="tableData"/>
    </i-col>
  </Row>
</template>

<script>
import { getArrayFromFile, getTableDataFromArray } from '@/libs/util'
export default {
  name: 'update_table_page',
  data () {
    return {
      columns: [
      {
        key: "Feature",
        title: "Feature",
        __id: "zY12tC"
      },
      {
        key: "Instance",
        title: "Instance",
        __id: "QBXhIN"
      },
      {
        key: "LocX",
        title: "LocX",
        __id: "EWMI9T"
      },
      {
        key: "LocY",
        title: "LocY",
        __id: "BNUIJc"
      },
      {
        key: "Checkin",
        title: "Checkin",
        __id: "NELLgy"
      }
    ],
      tableData: [
        {
          Checkin: "",
          Feature: "1",
          Instance: "A",
          LocX: "116.247692",
          LocY: "40.064857"
        },
        {
          Checkin: "",
          Feature: "1",
          Instance: "A",
          LocX: "116.247692",
          LocY: "40.064857"
        },
        {
          Checkin: "",
          Feature: "1",
          Instance: "A",
          LocX: "116.247692",
          LocY: "40.064857"
        },
        {
          Checkin: "",
          Feature: "1",
          Instance: "A",
          LocX: "116.247692",
          LocY: "40.064857"
        },
        {
          Checkin: "",
          Feature: "1",
          Instance: "A",
          LocX: "116.247692",
          LocY: "40.064857"
        },
        {
          Checkin: "",
          Feature: "1",
          Instance: "A",
          LocX: "116.247692",
          LocY: "40.064857"
        },
      ]
    }
  },
  methods: {
    beforeUpload (file) {
      getArrayFromFile(file).then(data => {
        let {tableData } = getTableDataFromArray(data)
        this.tableData = tableData
        console.log(this.tableData, "455555555555555555")
      }).catch(() => {
        this.$Notice.warning({
          title: '只能上传Csv文件',
          desc: '只能上传Csv文件，请重新上传'
        })
      })
      return false
    }
  }
}
</script>

<style>
.update-table-intro{
  margin-top: 10px;
}
.code-high-line{
  color: #2d8cf0;
}
</style>



<!-- <template>
  <Row :gutter="10">
    <i-col span="6">
      <Card>
        <p>util.js提供两个方法用来解析Csv文件：</p>
        <p class="update-table-intro"><Icon style="margin-right: 10px;" :size="10" type="md-heart"/><span class="code-high-line">getArrayFromFile</span>：将Csv文件解析为二维数组</p>
        <p class="update-table-intro"><Icon style="margin-right: 10px;" :size="10" type="md-heart"/><span class="code-high-line">getTableDataFromArray</span>：将二维数组转为表格数据，具体请看文档</p>
      </Card>
    </i-col>
    <i-col span="18">
      <Table :height="500" :columns="columns" :data="tableData"/>
    </i-col>
  </Row>
</template>

<script>
import { getArrayFromFile, getTableDataFromArray } from '@/libs/util'
import axios from 'axios'

export default {
  name: 'update_table_page',
  data() {
    return {
      columns: [],
      tableData: [],
      filePath: '/C:/Users/huawei/Desktop/output.csv' // 指定CSV文件路径
    }
  },
  mounted() {
    this.loadCsvData()
  },
  methods: {
    loadCsvData() {
      axios.get(this.filePath)
        .then(response => {
          const csvContent = response.data
          const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
          const file = new File([blob], 'sample.csv', { type: 'text/csv' })

          getArrayFromFile(file).then(data => {
            const { columns, tableData } = getTableDataFromArray(data)
            this.columns = columns
            this.tableData = tableData
          }).catch(() => {
            this.$Notice.warning({
              title: '数据解析失败',
              desc: '请检查CSV文件格式'
            })
          })
        })
        .catch(() => {
          this.$Notice.error({
            title: '加载失败',
            desc: '无法加载指定路径的CSV文件，请检查文件路径'
          })
        })
    }
  }
}
</script>

<style>
.update-table-intro {
  margin-top: 10px;
}
.code-high-line {
  color: #2d8cf0;
}
</style> -->
