<style lang="less">
  @import './login.less';
</style>

<template>
  <div class="login">
    <div class="login-con">
      <Card icon="log-in" title="欢迎登录" :bordered="false">
        <div class="form-con">
          <login-form @on-success-valid="handleSubmit"></login-form>
          <p class="login-tip">输入任意用户名和密码即可</p>
        </div>
      </Card>
    </div>
  </div>
</template>

<script>
import LoginForm from '_c/login-form'
import { mapActions } from 'vuex'
import {logintest} from '@/api/data'
export default {
  data:{
    loginsign:0
  },
  components: {
    LoginForm
  },
  methods: {
    ...mapActions([
      'handleLogin',
      'getUserInfo'
    ]),
    // handleSubmit ({ userName, password }) {
    //   // userName = "super_admin"
    //   // password = "super_admin"
    //   // this.handleLogin({ userName, password }).then(res => {
    //   //   this.getUserInfo().then(res => {
    //       this.$router.push({
    //         name: this.$config.homeName
    //       })
    //   //   })
    //   // })
    //   // console.log(userName)
    //   // var username = userName
    //   // var password = password
    //   // console.log(username)
    //   // logintest(username,password).then(ddd=>{
    //   //   console.log(ddd.data.msg)
    //   //   if(ddd.data.msg ==="SUCESS"){
    //   //         this.$router.push({
    //   //         name: this.$config.homeName
    //   //         })
    //   //     console.log(this.$config.homeName)
    //   //     this.$router.push({
    //   //       name: this.$config.homeName
    //   //     })
    //   //   }
    //   //   else if(ddd.data.msg ==="没有该用户"){
    //   //     console.log(ddd.data.msg)
    //   //   }
    //   //   else{
    //   //     console.log(ddd.data.msg)
    //   //   }
    //   // }).catch(err =>{
    //   //     console.log(err)
    //   // })
    // }
    handleSubmit ({ userName, password }) {
      this.loginsign = 0
      var username = userName
      var password = password
      console.log(username)
      logintest(username,password).then(ddd=>{
        console.log(ddd.data.msg)
        console.log("返回的结果"+ddd.data.msg)
        if(ddd.data.msg ==="SUCESS"){           //后端请求返回的结果为SUCESS的跳转首页界面
          this.handleLogin({ userName, password }).then(res => {
          this.getUserInfo().then(res => {
          console.log(this.$config.homeName)
          this.$router.push({
            name: this.$config.homeName
          })
        })
      })
        }
        else if(ddd.data.msg ==="没有该用户"){      //后端请求返回的结果为没有该用户的跳转列表详情界面
          console.log("返回的结果"+ddd.data.msg)
          var super_admin = 'super_admin'
          this.handleLogin({ super_admin, super_admin }).then(res => {
          this.getUserInfo().then(res => {
          console.log(this.$config.homeName)
          this.$router.push({
            name: 'error_store_page'//跳转到列表详情的界面
          })
        })
      })
          // this.$alert('密码错误或用户名错误', '错误', {
          // confirmButtonText: '重新输入'
          // })
        }
        else{                                               //后端请求返回的结果为密码错误的跳转列表详情的界面
          console.log("返回的结果"+ddd.data.msg)
          var super_admin = 'super_admin'
          this.handleLogin({ super_admin, super_admin }).then(res => {
          this.getUserInfo().then(res => {
          console.log(this.$config.homeName)
          this.$router.push({
            name: 'error_store_page'//跳转到列表详情的界面
          })
        })
      })
          // this.$alert('密码错误或用户名错误', '错误', {
          // confirmButtonText: '重新输入'
          // })
        }
      }).catch(err =>{
          console.log(err)
      })
      console.log("标识符是"+this.loginsign)
      if(this.loginsign === 0){
        
      }
      else if(this.loginsign === 1){
        
      }
      
    }
  }
}
</script>

<style>

</style>
