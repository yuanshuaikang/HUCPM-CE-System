<template>
  <!-- <div>
    <Card>
      iview-admin会自动将你程序中的错误收集起来，你可以将错误日志发给后端保存起来。如果你不需要这个功能，将'./src/config/index.js'里的plugin的'error-store'属性删掉即可。
      另外在开发环境下，你程序中的错误都会被收集起来，这样可能不利于你排查错误，你可以将'./src/config/index.js'的'error-store'的'developmentOff'设为true。
      如果你只是想收集错误日志，不希望登录用户看到错误日志，你可以不提供查看日志的入口，只需将'./src/config/index.js'的'error-store'的'showInHeader'设为false。
    </Card>
    <Card style="margin-top: 20px;">
      <Row>
        <i-col span="8">
          <Button @click="click" style="display: block">点击测试触发程序错误</Button>
          <Button @click="ajaxClick" style="margin-top:10px;">点击测试触发ajax接口请求错误</Button>
        </i-col>
        <i-col span="16">
          ajax接口请求是请求easy-mock的一个不存在接口，所以服务端会报404错误，错误收集机制会收集这个错误，测试的时候有一定网络延迟，所以点击按钮之后稍等一会才会收集到错误。
        </i-col>
      </Row>
    </Card>
  </div> -->
  
  <Card >
    <el-dialog
  title="商品图片"
  :visible.sync="dialogVisible"
  width="30%"
  >
  <el-image
      style="width: 400px; height: 500px"
      :src="picuter"
      fit=fill></el-image>
  <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
  </span>
</el-dialog>
  <el-table
    :data="tableData"
    border
    max-height = "540"
    style="width: 100%;"
     >
    <el-table-column
      fixed
      prop="id"
      label="id"
      width="80">
    </el-table-column>
    
    <el-table-column
      prop="name"
      label="网站"
      width="220">
    </el-table-column>
    <!-- 
    <el-table-column
      prop="price"
      label="商品价格"
      width="80">
    </el-table-column>
    <el-table-column
      prop="commitment"
      label="评论数目"
      width="80">
    </el-table-column> -->
    <el-table-column
      prop="describeMsg"
      label="商品描述"
      width="1000">
    </el-table-column>
    <el-table-column
      prop="label"
      label="LDA抽取主题标签"
      width="250">
    </el-table-column>
    <!-- <el-table-column
      prop="href"
      label="商品链接"
      width="280">
    </el-table-column>
    <el-table-column
      fixed="right"
      label="操作"
      width="100">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row)" type="text" size="small">查看商品图片</el-button> -->
        <!-- <el-button type="text" size="small">编辑</el-button> -->
      <!-- </template>
    </el-table-column> -->
  </el-table>
  <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page.sync="currentPage1"
      :page-size="10"
      layout="total, prev, pager, next"
      :total="500">
  </el-pagination>
  <!-- <el-image
      style="width: 100px; height: 100px"
      :src="href"
      :fit="fit"></el-image> -->
  </Card>
  
</template>


<!-- <script>
import { errorReq } from '@/api/data'
export default {
  name: 'error_store_page',
  methods: {
    click () {
      console.log(admin)
    },
    ajaxClick () {
      errorReq()
    }
  }
}
</script> -->
<script>
import {getAllshopping_msg} from '@/api/data'
import {getallpicuter} from '@/api/data'
  export default {
    methods: {
      handleClick(row) {
        console.log(row.pictuer);
        this.dialogVisible = true
        this.picuter = row.pictuer
        // const h = this.$createElement;
        // this.$msgbox({
        //   title: '消息',
        //   message: h('p', null, [
        //     h('img', null, src="https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png"),
        //     h('i', { style: 'color: teal' }, 'VNode')
        //   ]),
        //   showCancelButton: true,
        //   confirmButtonText: '确定',
        //   cancelButtonText: '取消',

        // }).then(action => {
        //   this.$message({
        //     type: 'info',
        //     message: 'action: ' + action
        //   });
        // });
      },
      load () {
        console.log(1);
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        const page = val
        console.log(val)
        getAllshopping_msg(page,'空调').then(res =>{
          console.log(res)
          this.tableData = res.data.data.records
        }).catch(err =>{
          console.log(err)
        })
      },
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      }
    },

    data() {
      return {
        fits: ['fill', 'contain', 'cover', 'none', 'scale-down'],
        picuter:'',
        href:'',
        wordcloud:[],
        currentPage1: 1,
        dialogVisible: false,
        tableData: [{
          // "id": 498,
          // "name": "美的(Midea) 1.5匹 新一级能效变频 智能冷暖壁挂式",
          // "price": "¥",
          // "pictuer": "https://imgservice4.suning.cn/uimg1/b2c/image/BVEc7QCIQ1W8nSKTNkkYxA.jpg_400w_400h_4e",
          // "commitment": "21万+",
          // "describeMsg": "美的(Midea) 1.5匹 新一级能效变频 智能冷暖壁挂式",
          // "label": "美的(Midea) 1.5匹 新一级能效变频 智能冷暖壁挂式",
          // "href": "美的(Midea) 1.5匹 新一级能效变频 智能冷暖壁挂式"
        }]
      }
    },
    mounted () {
    getAllshopping_msg(1,'空调').then(res =>{
      // console.log(res)
      this.tableData = res.data.data.records
    }).catch(err =>{
      console.log(err)
    }),
    getallpicuter().then(res =>{
      
      this.wordcloud = res.data.data
      
      this.href = "data:image/png;base64,"+ this.wordcloud[1].hre
      console.log(this.href)
      // this.href = "https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg"
    }).catch(err =>{
      console.log(err)
    })
    //
  }
  }
</script>

<style>

</style>
