import customBreadCrumb from './custom-bread-crumb.vue'
export default customBreadCrumb
