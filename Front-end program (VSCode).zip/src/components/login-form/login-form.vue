<template>
  <Form ref="loginForm" :model="form" :rules="rules" @keydown.enter.native="handleSubmit">
    <FormItem prop="userName">
      <Input v-model="form.userName" placeholder="请输入用户名">
        <span slot="prepend">
          <Icon :size="16" type="ios-person"></Icon>
        </span>
      </Input>
    </FormItem>
    <FormItem prop="password">
      <Input type="password" v-model="form.password" placeholder="请输入密码">
        <span slot="prepend">
          <Icon :size="14" type="md-lock"></Icon>
        </span>
      </Input>
    </FormItem>
    <FormItem>
      <Button @click="handleSubmit" type="primary" long>登录</Button>
    </FormItem>
  </Form>
</template>

<script>
import {getAllshopping_msg} from '@/api/data'
import {logintest} from '@/api/data'
export default {
  name: 'LoginForm',
  props: {
    userNameRules: {
      type: Array,
      default: () => {
        return [
          { required: true, message: '账号不能为空', trigger: 'blur' }
        ]
      }
    },
    passwordRules: {
      type: Array,
      default: () => {
        return [
          { required: true, message: '密码不能为空', trigger: 'blur' }
        ]
      }
    }
  },
  data () {
    return {
      form: {
        userName: 'super_admin',
        password: ''
      }
    }
  },
  mounted () {
    // getAllshopping_msg(1,'空调').then(res =>{
    //   console.log(res)
    //   this.shopping_msg = res.data
    // }).catch(err =>{
    //   console.log(err)
    // }),
    // logintest('root','root').then(ddd=>{
    //     console.log(ddd)
    //     if(ddd.data.msg ==="SUCESS"){
    //       // console.log(1)
    //       this.$emit('on-success-valid', {
    //         userName: "root",
    //         password: "root"
    //       })
    //     }
    //     else if(ddd.data.msg ==="没有该用户"){
    //       console.log(ddd.data.msg)
    //     }
    //     else{
    //       console.log(ddd.data.msg)
    //     }
    //   }).catch(err =>{
    //       console.log(err)
    //   })
    
  },
  computed: {
    rules () {
      console.log(this.userNameRules)
      console.log(this.passwordRules)
      return {
        userName: this.userNameRules,
        password: this.passwordRules
      }
    }

  },
  methods: {
    // handleSubmit () {
    //   // console.log(this.form.userName)
    //   // console.log(this.form.password)
    //   // this.$refs.loginForm.validate((valid) => {
    //   //   if (valid) {
    //     this.$emit('on-success-valid', {
    //         userName: "root",
    //         password: "root"
    //       })    
      
          


    //   //   }
    //   // })
    // }
    handleSubmit () {
      this.$refs.loginForm.validate((valid) => {
        if (valid) {
          this.$emit('on-success-valid', {
            userName: this.form.userName,
            password: this.form.password
          })
        }
      })
    }
  }
}
</script>
