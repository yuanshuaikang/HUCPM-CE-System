<template>
  <div ref="dom" class="charts chart-bar"></div>
</template>

<script>
import echarts from 'echarts'
import tdTheme from './theme.json'
import { on, off } from '@/libs/tools'
echarts.registerTheme('tdTheme', tdTheme)
export default {
  name: 'ChartBar',
  props: {
    value: Object,
    text: String,
    subtext: String
  },
  data () {
    return {
      dom: null
    }
  },
  methods: {
    resize () {
      this.dom.resize()
    }
  },
  mounted () {
    this.$nextTick(() => {
      let xAxisData = Object.keys(this.value)
      let seriesData = Object.values(this.value)
      let option = {
        title: {
          text: 'High utility patterns probability distribution',
          subtext: this.subtext,
          x: 'center',
          textStyle: {
            fontSize: '20',
            fontWeight: 'bold',
            color: '#333'
          },
        },
        
        grid: {
          top: '12%',
          left: '2%',
          right: '2%',
          bottom: '1%',
          containLabel: true
        },

        xAxis: {
          type: 'category',
          data: xAxisData,
          axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 14] 
            },
          axisLabel: {
            show: true,
            color: '#000', // 设置刻度字体颜色为黑色
            fontSize: 'auto',   // 设置字体大小（可选）
            // fontWeight: 'bold' // 设置字体加粗（可选）
          }  
        },

        yAxis: {
          type: 'value',
          min: 0,
          max: 100,
          interval: 10,
          axisLine: {
              show: true,
              lineStyle: {
                color: '#333',  // 设置轴线的颜色
                width: 2,       // 设置轴线的宽度
                type: 'solid'   // 轴线的类型
              },
              symbol: ['none', 'arrow'],  // 设置轴线末端为箭头
              symbolSize: [10, 15], // 设置箭头的大小
              symbolOffset: [0, 14]  
            },
          axisLabel: {
            show: true,
            color: '#000', // 设置刻度字体颜色为黑色
            fontSize: '12',   // 设置字体大小（可选）
            // fontWeight: 'bold' // 设置字体加粗（可选）
          },
          name: 'Probability (%)',            // 纵坐标名称
          nameLocation: 'middle',   // 纵坐标名称位置，可以是 'start', 'middle', 'end'
          nameGap: 25,           // 坐标轴名称与轴线的距离
          nameTextStyle: {
            color: '#333',           // 坐标轴名称的颜色（例如深橙色）
            fontSize: 16,               // 坐标轴名称的字体大小
            fontWeight: 'bold',         // 坐标轴名称的字体加粗
            fontFamily: 'Arial',        // 坐标轴名称的字体
          }
        },

        series: [{
          data: seriesData,
          type: 'bar',
          itemStyle: {
            color: '#B22222', 
            borderColor: '#333',
            borderWidth: 1, 
          },
          barWidth: 25, // 设置柱子的宽度
          label: {
              normal: {
                show: true,
                position: 'top'
              }
            },
        }]
      }

      this.dom = echarts.init(this.$refs.dom, 'tdTheme')
      this.dom.setOption(option)

      on(window, 'resize', this.resize)
    })
  },
  beforeDestroy () {
    off(window, 'resize', this.resize)
  }
}
</script>
