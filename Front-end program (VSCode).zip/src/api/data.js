import axios from '@/libs/api.request'

export const getAllshopping_msg = (page,infor) =>{
  return axios.request({
    // url: 'http://127.0.0.1:8081/goods/gettest?showpage='+page+'&shopping_kinds='+infor,
    url:'/goods/gettest?showpage='+page+'&shopping_kinds='+infor,
    method: 'get'
  })
}

export const getallpicuter = () =>{
  return axios.request({
    // url: 'http://127.0.0.1:8081/goods/gettest?showpage='+page+'&shopping_kinds='+infor,
    url:'/pictuer/gettest1',
    method: 'get'
  })
}

export const getcolocation = (info) => {
  return axios.request({
    url: '/getdata111',
    data: info,
    method: 'post'
  })
}

export const logintest = (usersname,secret) =>{
  return axios.request({
    // url: 'http://127.0.0.1:8081/goods/gettest?showpage='+page+'&shopping_kinds='+infor,
    url:'/users/login?username='+usersname+'&secret='+secret,
    method: 'get'
  })
}

export const getTableData = () => {
  return axios.request({
    url: 'get_table_data',
    method: 'get'
  })
}

export const getDragList = () => {
  return axios.request({
    url: 'get_drag_list',
    method: 'get'
  })
}

export const errorReq = () => {
  return axios.request({
    url: 'error_url',
    method: 'post'
  })
}

export const saveErrorLogger = info => {
  return axios.request({
    url: 'save_error_logger',
    data: info,
    method: 'post'
  })
}

export const uploadImg = formData => {
  return axios.request({
    url: 'image/upload',
    data: formData
  })
}

export const getOrgData = () => {
  return axios.request({
    url: 'get_org_data',
    method: 'get'
  })
}

export const getTreeSelectData = () => {
  return axios.request({
    url: 'get_tree_select_data',
    method: 'get'
  })
}
